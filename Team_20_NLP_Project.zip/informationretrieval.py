#from util import *
import pandas as pd
import numpy as np
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import gensim.downloader as api
from sklearn.decomposition import TruncatedSVD
import opt_einsum as oe
import scipy

model = api.load("glove-wiki-gigaword-300")


class InformationRetrieval():

    def __init__(self):
        self.index = None
        self.doc_num = None

    def buildIndex(self, docs, docIDs):
        """
        Builds the document index in terms of the document
        IDs and stores it in the 'index' class variable

        Parameters
        ----------
        arg1 : list
            A list of lists of lists where each sub-list is
            a document and each sub-sub-list is a sentence of the document
        arg2 : list
            A list of integers denoting IDs of the documents
        Returns
        -------
        None
        """
        self.docs=[]
        self.docIDs = docIDs
        self.doc_num = len(docIDs)
        for doc in docs:
            d=''
            for sentence in doc:
                sent=' '.join(sentence)
                d+=sent
            self.docs.append(d)
        #Fill in code here
        tfidf=TfidfVectorizer()
        tfidfv=tfidf.fit_transform(self.docs).toarray()
        words_set = tfidf.get_feature_names_out()
        self.vocab=tfidf.vocabulary_
        tfidf_df = pd.DataFrame(tfidfv,columns=words_set)
        self.tfidf=tfidf
        return tfidf_df

    def tfidfq(self,queries):
        q=[]
        for query in queries:
            query1=''
            for sentence in query:
                sent=' '.join(sentence)
                query1+=sent
            q.append(query1)
        tfidfq=self.tfidf.transform(q).toarray()
        c=self.tfidf.get_feature_names_out()
        tfidfq_df=pd.DataFrame(tfidfq,columns=c)
        return tfidfq_df
    
    def lsa_doc(self, doc_df, k):
        self.lsa = TruncatedSVD(k, random_state = 42)
        self.lsa.fit(doc_df)
        self.sigma=np.diag(self.lsa.singular_values_)
        self.v_trans = self.lsa.components_
        doc_mat=self.lsa.transform(doc_df)
        doc_dfv=doc_mat@self.v_trans
        doc_df=pd.DataFrame(doc_dfv,columns=doc_df.columns)
        return pd.DataFrame(doc_mat),pd.DataFrame(doc_df)
    
    def lsa_query(self, query_mat):
        qmat=self.lsa.transform(query_mat)
        q_dfv=qmat@self.v_trans
        q_df=pd.DataFrame(q_dfv,columns=query_mat.columns)
        return pd.DataFrame(qmat),pd.DataFrame(q_df)    
    
    def w2v(self,df):
        embedding=np.zeros((len(df.columns),model.vector_size))
        for word, index in self.vocab.items():
            if word in model.key_to_index:
                embedding[index]=model[word]
        mdfre=np.dot(df,embedding)
        return pd.DataFrame(mdfre)

    def rank(self,doc_ids,doc_df,q_df):
        doc_ordered=[]
        q_a=np.array(q_df)
        for q in q_a:
            cosines=pd.DataFrame(cosine_similarity(doc_df,[q]))
            cosines['DocIDs']=self.docIDs
            cols=cosines.columns[0]
            doc_ordered.append(cosines.sort_values(cols,ascending=False)['DocIDs'])
        return doc_ordered